// NOTE 1: motor's max speed is about 15 rev/s so we need at least an  
// update freq of 50Hz (20 ms) for the odometry to be able to measure at
// least 100-ish angular speed levels. This quantization WILL affect the
// speed controller's behavior if the set-point is an unreachable speed 
// (oscillations). May be even better to make the controller work in desired 
// delta counts per second to be consistent with the measurement limitations. 
// Do a remapping of rpm values recieved via I2C to delta counts per second?
// OR better, just parametrize everything and check the performance.

// NOTE 2: the static json document has to have a max size of 32B (to
// match the buffer size of Arduino's Wire library), this can be achieved 
// by using the odometry data in mm (1mm resolution), the yaw angle in 
// degrees (0.5° resolution) and the raw value of delta counts per wheel, 
// which will always be in the 100s given NOTE 1. This gives a max json 
// string length of 30, taking into account a case of all minus signs.
// This quantization does NOT degrade the measurement's accuracy.

// NOTE 3: remember to flush the I2C buffer in the initialization and 
// for every corrupted message received.

// NOTE 4: disregard NOTE 2 if using CBOR
#include <Arduino.h>
#include <Pololu3piPlus32U4.h>
#include <pt.h>
#include <tinycbor.h>
#include <math.h>
//#include <SoftwareSerial.h>

#define USE_TIMER_3 (true)
#include <TimerInterrupt.h>

// #define USE_OLED_DISPLAY
// #define OLED_PRINT_MSG

using namespace Pololu3piPlus32U4;

// 3piPlus hardware definitions
Encoders encoders;
Motors motors;
#ifdef USE_OLED_DISPLAY
  OLED display;
#else
  #define CBOR_BUF_SIZE     (32)
  #define CBOR_MSG_MIN_SIZE (11)
  // CBOR buffers
  uint8_t uart_send_buffer[CBOR_BUF_SIZE];
  uint8_t uart_receive_buffer[CBOR_BUF_SIZE];
  unsigned int receive_buf_idx = 0;
  bool b_is_invalid_data = false;
  bool b_is_first_float = true;
#endif


// Robot's kinematic info
static const float ticks_per_rev = 29.86 * 12; // 12 step encoder with a 29.86:1 gear ratio
static const float wheel_radius = 16; // in mm
static const float wheel2wheel_distance = 96.0 - 6.8; // in mm
static const float max_speed = 850; // in rpm (measured)

// Sampling and threading times
static const unsigned int sample_time_ms = 20;
static const float dt = (1.0f * sample_time_ms) / 1000.0f; // 20 ms
static const float sample_freq = 1 / dt; // in Hz
#ifdef USE_OLED_DISPLAY
  static const unsigned int display_time_ms = 100;
#else
  static const unsigned int encode_time_ms = 100;
#endif

// Odometry definitions
volatile int16_t delta_ell;
volatile int16_t delta_r;
volatile float left_speed;
volatile float right_speed;
volatile float odo_dr;
volatile float odo_dell;
volatile float odo_dc;
volatile float odo_x = 0; // in mm (~0.3 mm resolution)
volatile float odo_y = 0; // in mm (~0.3 mm resolution)
volatile float odo_theta = 0; // in rad (~0.003 rad resolution) 

// Control definitions
static const float max_counts_per_dt = (max_speed / 60) * ticks_per_rev * dt;
static const float speed_resolution = max_speed / max_counts_per_dt;
static const float speed_to_pwm = 400 / max_speed;
volatile float rl_k = 0; //-50;//25;//200; // rpm 
volatile float rr_k = 0; //50;//70;//200; // rpm
volatile float ul_k;
volatile float ur_k;

// Protothread's data structures definitions
#ifdef USE_OLED_DISPLAY
  pt pt_display;
#else
  pt pt_uart_encode;
  pt pt_uart_parse;
#endif


static inline float
quantize_speed(float rpm)
{
  return round(rpm / speed_resolution) * speed_resolution;
}

// static inline float 
// rpm_to_ffw(float rpm)
// {
//   return 0.454*rpm - 0.2136;
// }


static inline void
odometry_and_control_thread()
{
  #ifdef ENCODER_ERROR_CHECK
  if((!encoders.checkErrorLeft()) && (!encoders.checkErrorLeft()))
  {
  #endif
  // Get ticks since last update
  delta_ell = encoders.getCountsAndResetLeft(); // 8us_|
  delta_r = encoders.getCountsAndResetRight();
  // Get motors' speed in rpm
  left_speed = ((delta_ell / ticks_per_rev) / dt) * 60; // rpm, 20us_|
  right_speed = ((delta_r / ticks_per_rev) / dt) * 60; // rpm
  // Update state estimate
  odo_dell = 2 * M_PI * wheel_radius * (delta_ell / ticks_per_rev);
  odo_dr = 2 * M_PI * wheel_radius * (delta_r / ticks_per_rev);
  odo_dc = (odo_dell + odo_dr) / 2;
  odo_x += odo_dc * cos(odo_theta);
  odo_y += odo_dc * sin(odo_theta);
  odo_theta += (odo_dr - odo_dell) / wheel2wheel_distance;
  
  ul_k += 0.5*(rl_k - left_speed);
  ur_k += 0.5*(rr_k - right_speed);
  // ul_k = 2.5*(rl_k - left_speed);
  // ur_k = 2.5*(rr_k - right_speed);
  #ifdef ENCODER_ERROR_CHECK
  }
  #endif

  motors.setSpeeds(ul_k * speed_to_pwm, ur_k * speed_to_pwm); // 40us_| 
  // motors.setSpeeds(400, 400); // to measure avg max speed
}

#ifdef USE_OLED_DISPLAY
int
display_thread(struct pt * pt)
{
  static unsigned long last_display_update = 0;
  PT_BEGIN(pt);
  while(1) 
  {
    PT_YIELD_UNTIL(pt, millis() - last_display_update >= display_time_ms);
    // Update the screen with encoder counts and error info.
    display.noAutoDisplay();
    display.clear();
    
    #ifdef OLED_PRINT_MSG
      display.gotoXY(2, 1);
      display.print("EXPLORA EL UNIVERSO");
      display.gotoXY(9, 2);
      display.print("UVG"); 
      display.gotoXY(3, 4);
      display.print("EXPERIENCIA 2023");
      display.gotoXY(6, 6);
      display.print("18 DE MARZO");
    #else
      display.print(left_speed);
      display.gotoXY(0, 1);
      display.print(right_speed);
      display.gotoXY(0, 2);
      display.print(odo_x);
      display.gotoXY(0, 3);
      display.print(odo_y);
      display.gotoXY(0, 4);
      display.print(odo_theta);
      // display.print(rpm_to_ffw(rl_k));
    #endif

    display.display();
    last_display_update = millis();
  }
  PT_END(pt);
}
#else
int
uart_encode_thread(struct pt * pt)
{
  static unsigned long last_encode_time = 0;
  PT_BEGIN(pt);
  while(1) 
  {
    PT_YIELD_UNTIL(pt, millis() - last_encode_time >= encode_time_ms);
    // Encode the odometry data to CBOR and send via Serial1.
    float temp_odo[3] = {odo_x, odo_y, odo_theta};
    TinyCBOR.Encoder.init(uart_send_buffer, sizeof(uart_send_buffer));
    TinyCBOR.Encoder.create_array(3);
    TinyCBOR.Encoder.encode_float(temp_odo[0]);
    TinyCBOR.Encoder.encode_float(temp_odo[1]);
    TinyCBOR.Encoder.encode_float(temp_odo[2]);
    TinyCBOR.Encoder.close_container();
    Serial1.write(TinyCBOR.Encoder.get_buffer(), TinyCBOR.Encoder.get_buffer_size());
    //Serial1.println("Test");
    last_encode_time = millis();
  }
  PT_END(pt);
}

int
uart_parse_thread(struct pt * pt)
{
  PT_BEGIN(pt);
  while(1) 
  {
    PT_YIELD_UNTIL(pt, Serial1.available());
    uart_receive_buffer[receive_buf_idx++] = Serial1.read();
    if(receive_buf_idx >= CBOR_MSG_MIN_SIZE)
    {
      TinyCBOR.Parser.init(uart_receive_buffer, sizeof(uart_receive_buffer), 0);
      b_is_invalid_data = false;
      while((!TinyCBOR.Parser.at_end_of_data()) && (!b_is_invalid_data))
      {
        int ty = TinyCBOR.Parser.get_type();
        switch(ty)
        {
          case CborArrayType:
          case CborMapType:
            TinyCBOR.Parser.enter_container();
            break;

          case CborInvalidType:
            if(TinyCBOR.Parser.at_end_of_container()) 
            {
              TinyCBOR.Parser.leave_container();
              receive_buf_idx = 0; // parsing ended, restart index
              b_is_first_float = true;
            }
            else 
            {
              receive_buf_idx = 0; // invalid data, restart index
              b_is_first_float = true;
              b_is_invalid_data = true;
            }
            break;

            case CborFloatType:
              if((TinyCBOR.Parser.is_in_array()) || (TinyCBOR.Parser.is_in_map()))
              {
                if(b_is_first_float)
                {
                  rl_k = quantize_speed(TinyCBOR.Parser.get_float());
                  b_is_first_float = false;
                }
                else
                {
                  rr_k = quantize_speed(TinyCBOR.Parser.get_float());
                  b_is_first_float = true;
                }
              }
              else
              {
                receive_buf_idx = 0; // invalid data, restart index
                b_is_first_float = true;
                b_is_invalid_data = true;
              }
              break;

            default:
              receive_buf_idx = 0; // invalid data, restart index
              b_is_first_float = true;
              b_is_invalid_data = true;
              break;
        }
      }
    }
    else
    {
      PT_YIELD(pt);
    }

    // if(int msglen = Serial1.available() >= CBOR_MSG_MIN_SIZE)
    // {
    //   // Get CBOR msg and parse it
    //   Serial1.readBytes(uart_receive_buffer, msglen);
    //   TinyCBOR.Parser.init(uart_receive_buffer, sizeof(uart_receive_buffer), 0);
    //   TinyCBOR.Parser.enter_container();
    //   rl_k = quantize_speed(TinyCBOR.Parser.get_float());
    //   rr_k = quantize_speed(TinyCBOR.Parser.get_float());
    //   TinyCBOR.Parser.leave_container();
    // }
    // else
    // {
    //   PT_YIELD(pt);
    // }
  }
  PT_END(pt);
}
#endif

void 
timer3_isr_handler()
{
  odometry_and_control_thread();
}


void 
setup()
{
  // Waits for the 5V rail to stabilize, since the device was having boot issues 
  // when combined with the ESP32
  delay(500);
  #ifdef USE_OLED_DISPLAY
    display.setLayout21x8();
    PT_INIT(&pt_display);
  #else
    TinyCBOR.init();
    Serial1.begin(115200);
    PT_INIT(&pt_uart_encode);
    PT_INIT(&pt_uart_parse);
  #endif
  
  ITimer3.init();
  ITimer3.attachInterrupt(sample_freq, timer3_isr_handler);
  rl_k = quantize_speed(rl_k);
  rr_k = quantize_speed(rr_k);
}


void 
loop()
{
  #ifdef USE_OLED_DISPLAY
    PT_SCHEDULE(display_thread(&pt_display));
  #else
    PT_SCHEDULE(uart_encode_thread(&pt_uart_encode));
    PT_SCHEDULE(uart_parse_thread(&pt_uart_parse));
  #endif
}