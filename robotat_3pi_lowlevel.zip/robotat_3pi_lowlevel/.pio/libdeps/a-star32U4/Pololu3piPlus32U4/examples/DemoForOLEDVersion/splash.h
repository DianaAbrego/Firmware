extern const uint8_t PROGMEM pololu3PiPlusSplash[1024];

